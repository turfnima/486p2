/**
 * Copyright (c) 1992-1993 The Regents of the University of California.
 * All rights reserved.  See copyright.h for copyright notice and limitation 
 * of liability and disclaimer of warranty provisions.
 *  
 *  Created by Patrick McSweeney on 12/5/08.
 */
package jnachos.kern.sync;

/** */
public class Lock {
	/** */
	private String mName;

	public void delete() {

	}

	public void acquire() {

	}

	public void release() {

	}

	public Lock(String pName) {
		mName = pName;
	}

}
